import { FromWeiPipe } from './from-wei.pipe';

describe('FromWeiPipe', () => {
  it('create an instance', () => {
    const pipe = new FromWeiPipe();
    expect(pipe).toBeTruthy();
  });
});
