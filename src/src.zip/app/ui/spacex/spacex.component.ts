import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spacex',
  templateUrl: './spacex.component.html',
  styleUrls: ['./spacex.component.scss']
})
export class SpacexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
